nombre = input("Cual es tu nombre?")
apellido = input("Cual es tu apellido?")
nombreCompleto = nombre + "" + apellido

print("Hola, " + nombreCompleto + "!")
print("Bienvenido al programa!")

print(type(nombreCompleto))
print(nombreCompleto.upper())