a = int(input("Ingresa el primer numero: "))
b = float(input("Ingresa el segundo numero: "))

c = a + b
print("La suma de los datos es: ", c)

c = a - b
print("La resta de los datos es: ", c)

c = a * b
print("La multiplicacion de los datos es: ", c)

c = a / b
print("La division de los datos es: ", c)

c = a % b
print("El mnodulo de los datos es: ", c) #Modulo

c = a ** b
print("La potencia de los datos es: ", c) #Potencia