a = int(input("Introduce un numero: "))
b = float(input("Introduce otro numero: "))
c = a + b

print("La suma de los datos es: ", c)
print("El tipo de dato es: ", type(c))