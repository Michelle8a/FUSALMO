print("hola mundo")

a = 1
b = 5
c = a + b
print(c)

nombre = "Karina Michelle"
apellido = "Leiva Ochoa"
nombreCompleto = nombre + " " + apellido

print(a)
print(b)
print(nombreCompleto)
print(nombre , apellido) #esto tambien me pone un espacio