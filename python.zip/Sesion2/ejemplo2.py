num = int(input("Ingrese un numero: "))

if num % 2 == 0 or num % 3 == 0:
    print("El numero es divisible por 2 o por 3")
