

frutas = ["manzana", "banana", "cereza", "durazno", "kiwi"]

for fruta in frutas:
    print("Fruta:", fruta)

print(frutas[4]) #imprime el kiwi

print("Lista de frutas procesada exitosamente")
print("Total de frutas:", len(frutas))
print("Tipo de dato:", type(frutas))

