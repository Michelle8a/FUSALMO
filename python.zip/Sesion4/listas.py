
carro1 = "volvo"
carro2 = "audi"
carro3 = "bmw"
carro4 = "mercedes"
carro5 = "toyota"

print(type(carro1))


carros = ["volvo", "audi", "bmw", "mercedes", "toyota"]

print(type(carros))
print(type(carros[0]))

carros.sort() #Los ordena
print(carros)






