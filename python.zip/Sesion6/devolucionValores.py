
def suma(a, b):
    print(f"Valores: \na = {a} \nb = {b}")
    return a + b

c = suma(10, 5)
print(f"C tiene el valor de {c}")