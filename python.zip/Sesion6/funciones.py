#Funciones
def saludar():
    print("Hola mundo")

saludar()
saludar()
saludar()


def saludo(nombre = "Karina", apellidos = "Ochoa"):
    print("Hola", nombre)

saludo("Michelle")
saludo("Michelle", "Leiva")
saludo(apellidos = "Leiva")
saludo()
