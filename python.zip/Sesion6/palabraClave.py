
def info(edad, nombre, apellidos, sexo):
    print(f"Nombres: {nombre} {apellidos}")
    print(f"Edad: {edad}")
    print(f"Sexo: {sexo}")

info(26, "Karina Michelle", "Leiva Ochoa", "Mujer")

info(nombre="Kari", 
     apellidos="Ochoa", 
     edad=26, 
     sexo="Mujer")