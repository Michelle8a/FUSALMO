def saludar(nombre):
    print("Hola", nombre)


info = {
    "nombre" : "Karina",
    "edad": 26,
    "Estado Civil": "Soltera"
}