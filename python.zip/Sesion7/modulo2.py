import modulo as m1
import Sesion6.ejercicio3 as s6

m1.saludar("Jose")

print(m1.info['edad'])

edad = m1.info['edad']
print(edad)
