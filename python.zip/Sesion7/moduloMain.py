import modulo

modulo.saludar("Manuel")
modulo.saludar("Jessica")


print(modulo.info['edad'])