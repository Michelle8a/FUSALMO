import platform

from modulo import info

x = platform.system()
print(x)

y = dir(platform)
print(y)

print(info['edad'])