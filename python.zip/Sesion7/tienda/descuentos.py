descuento = 5

def calcular_descuentos(precio, descuento):
    monto_descuento = precio * (descuento/100)
    return monto_descuento