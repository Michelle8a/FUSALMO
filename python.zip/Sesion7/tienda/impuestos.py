tasa = 0.1

def calcular_impuesto(precio, tasa):
    monto_impuestos = precio * tasa
    return monto_impuestos