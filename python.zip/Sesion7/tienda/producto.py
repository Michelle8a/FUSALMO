producto = {
    "manzana": 35,
    "pera": 20,
    "uva": 10,
    "sandia": 30,
    "kiwi": 15
}